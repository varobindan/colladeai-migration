import { useState } from "react";
import { GraduationCap, Search, ChevronRight } from "lucide-react";
import { useCredits } from "@/hooks/useCredits";
import { base44 } from "@/api/base44Client";
import SectionHeader from "../components/SectionHeader";
import CareerCard from "../components/CareerCard";
import LoadingGrid from "../components/LoadingGrid";
import { motion } from "framer-motion";

const LEVELS = ["Undergraduate", "Postgraduate", "Doctorate", "Diploma", "Professional Certification"];

const STREAMS = [
  "Science & Technology", "Commerce & Business", "Arts & Humanities", "Engineering",
  "Medicine & Health", "Law", "Design & Architecture", "Education",
  "Agriculture & Environment", "Media & Communication", "Social Sciences", "Performing Arts"
];

export default function ExploreDegrees() {
  const { deductCredit } = useCredits();
  const [selectedLevel, setSelectedLevel] = useState(null);
  const [selectedStream, setSelectedStream] = useState(null);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const fetchDegrees = async (level, stream) => {
    const spent = await deductCredit();
    if (!spent) { window.dispatchEvent(new CustomEvent("collade:upgrade")); return; }
    setLoading(true);
    setResults([]);
    try {
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a comprehensive career guidance database. List 12 diverse degrees/programs at the ${level} level in the ${stream} stream.

For each, provide detailed info. Include mainstream AND niche/emerging programs. Cover global options.

Return a JSON array of objects.`,
      response_json_schema: {
        type: "object",
        properties: {
          degrees: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                stream: { type: "string" },
                specialization: { type: "string" },
                level: { type: "string" },
                duration: { type: "string" },
                short_description: { type: "string" },
                salary_range: { type: "string" },
                ai_impact: { type: "string", enum: ["High", "Medium", "Low"] },
                growth: { type: "string" },
                locations: { type: "array", items: { type: "string" } },
                required_subjects: { type: "array", items: { type: "string" } },
                entrance_exams: { type: "array", items: { type: "string" } },
              }
            }
          }
        }
      },
      add_context_from_internet: true
    });
    setResults(res.degrees || []);
    } finally { setLoading(false); }
  };

  const handleStreamClick = (stream) => {
    setSelectedStream(stream);
    if (selectedLevel) {
      fetchDegrees(selectedLevel, stream);
    }
  };

  const handleLevelClick = (level) => {
    setSelectedLevel(level);
    if (selectedStream) {
      fetchDegrees(level, selectedStream);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    const spent = await deductCredit();
    if (!spent) { window.dispatchEvent(new CustomEvent("collade:upgrade")); return; }
    setLoading(true);
    setResults([]);
    setSelectedLevel(null);
    setSelectedStream(null);
    try {
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Search for degrees, courses, and programs related to: "${searchQuery}". Return 10 diverse results across all levels and streams globally.`,
      response_json_schema: {
        type: "object",
        properties: {
          degrees: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                stream: { type: "string" },
                specialization: { type: "string" },
                level: { type: "string" },
                duration: { type: "string" },
                short_description: { type: "string" },
                salary_range: { type: "string" },
                ai_impact: { type: "string", enum: ["High", "Medium", "Low"] },
                growth: { type: "string" },
                locations: { type: "array", items: { type: "string" } },
              }
            }
          }
        }
      },
      add_context_from_internet: true
    });
    setResults(res.degrees || []);
    } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Explore by Degree"
        subtitle="Browse programs by level and stream — from diplomas to doctorates"
        icon={GraduationCap}
      />

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          placeholder="Search any degree, e.g. 'Marine Biology', 'AI Engineering', 'Fashion Design'..."
          className="w-full bg-card border border-border rounded-xl pl-10 pr-4 py-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
      </div>

      {/* Level selector */}
      <div>
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Step 1 — Choose Level</p>
        <div className="flex flex-wrap gap-2">
          {LEVELS.map((level) => (
            <button
              key={level}
              onClick={() => handleLevelClick(level)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                selectedLevel === level
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "bg-card border border-border text-foreground hover:border-primary/30"
              }`}
            >
              {level}
            </button>
          ))}
        </div>
      </div>

      {/* Stream selector */}
      <div>
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Step 2 — Choose Stream</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {STREAMS.map((stream) => (
            <button
              key={stream}
              onClick={() => handleStreamClick(stream)}
              className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-all text-left ${
                selectedStream === stream
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "bg-card border border-border text-foreground hover:border-primary/30"
              }`}
            >
              <span className="truncate">{stream}</span>
              <ChevronRight className="h-3 w-3 shrink-0 ml-1" />
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      {loading && <LoadingGrid text="Finding degrees and programs..." />}

      {!loading && results.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-3"
        >
          <p className="text-sm text-muted-foreground">
            {results.length} programs found
            {selectedLevel && selectedStream ? ` for ${selectedLevel} in ${selectedStream}` : ""}
          </p>
          <div className="grid sm:grid-cols-2 gap-3">
            {results.map((degree, i) => (
              <CareerCard key={i} career={degree} index={i} />
            ))}
          </div>
        </motion.div>
      )}

      {!loading && results.length === 0 && (selectedLevel || selectedStream) && !selectedLevel && (
        <p className="text-center text-sm text-muted-foreground py-10">Select both a level and stream to see programs</p>
      )}
    </div>
  );
}