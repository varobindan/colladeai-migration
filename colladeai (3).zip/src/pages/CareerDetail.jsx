import { useState, useEffect } from "react";
import { ArrowLeft, Clock, MapPin, DollarSign, Zap, TrendingUp, BookOpen, GraduationCap, Users, Brain, Briefcase, Globe, Star } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import LoadingGrid from "../components/LoadingGrid";
import { motion } from "framer-motion";

export default function CareerDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const name = urlParams.get("name") || "";
  const stream = urlParams.get("stream") || "";
  const level = urlParams.get("level") || "";

  const [detail, setDetail] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!name) return;
    const fetchDetail = async () => {
      setLoading(true);
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Provide an extremely detailed career/degree guide for: "${name}"
${stream ? `Stream: ${stream}` : ""}
${level ? `Level: ${level}` : ""}

Include EVERYTHING a student would need to know. Be comprehensive, accurate, and engaging.`,
        response_json_schema: {
          type: "object",
          properties: {
            name: { type: "string" },
            full_title: { type: "string" },
            stream: { type: "string" },
            specialization: { type: "string" },
            level: { type: "string" },
            duration: { type: "string" },
            overview: { type: "string" },
            what_you_will_learn: { type: "array", items: { type: "string" } },
            required_subjects: { type: "array", items: { type: "string" } },
            entrance_exams: { type: "array", items: { type: "string" } },
            top_universities_india: { type: "array", items: { type: "string" } },
            top_universities_global: { type: "array", items: { type: "string" } },
            career_options: { type: "array", items: { type: "string" } },
            salary_india: { type: "string" },
            salary_global: { type: "string" },
            salary_entry: { type: "string" },
            salary_mid: { type: "string" },
            salary_senior: { type: "string" },
            ai_impact: { type: "string" },
            ai_impact_detail: { type: "string" },
            growth_potential: { type: "string" },
            growth_detail: { type: "string" },
            personality_fit: { type: "string" },
            stress_level: { type: "string" },
            work_life_balance: { type: "string" },
            skills_needed: { type: "array", items: { type: "string" } },
            future_proof_skills: { type: "array", items: { type: "string" } },
            popular_locations: { type: "array", items: { type: "string" } },
            emerging_specializations: { type: "array", items: { type: "string" } },
            related_certifications: { type: "array", items: { type: "string" } },
            internship_opportunities: { type: "string" },
            online_resources: { type: "array", items: { type: "string" } },
            day_in_the_life: { type: "string" },
            pros: { type: "array", items: { type: "string" } },
            cons: { type: "array", items: { type: "string" } },
            quick_summary: { type: "string" },
          }
        },
        add_context_from_internet: true
      });
      setDetail(res);
      setLoading(false);
    };
    fetchDetail();
  }, [name]);

  if (loading) return <LoadingGrid text={`Loading details for ${name}...`} />;
  if (!detail) return <p className="text-center py-20 text-muted-foreground">Career not found</p>;

  const InfoRow = ({ icon: Icon, label, value }) => {
    if (!value) return null;
    return (
      <div className="flex items-start gap-3 py-3 border-b border-border/50">
        <Icon className="h-4 w-4 text-primary mt-0.5 shrink-0" />
        <div>
          <p className="text-xs text-muted-foreground">{label}</p>
          <p className="text-sm font-medium mt-0.5">{value}</p>
        </div>
      </div>
    );
  };

  const TagSection = ({ title, items, color = "bg-secondary" }) => {
    if (!items || items.length === 0) return null;
    return (
      <div>
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">{title}</p>
        <div className="flex flex-wrap gap-1.5">
          {items.map((item, i) => (
            <span key={i} className={`text-xs ${color} px-2.5 py-1 rounded-md font-medium`}>{item}</span>
          ))}
        </div>
      </div>
    );
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      {/* Back button */}
      <button onClick={() => window.history.back()} className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="h-4 w-4" /> Back
      </button>

      {/* Header */}
      <div className="bg-gradient-to-br from-primary/10 via-accent/5 to-background border border-primary/10 rounded-2xl p-6">
        <div className="flex flex-wrap gap-2 mb-3">
          {detail.level && <span className="text-xs font-medium bg-primary/10 text-primary px-2.5 py-1 rounded-md">{detail.level}</span>}
          {detail.stream && <span className="text-xs font-medium bg-secondary px-2.5 py-1 rounded-md">{detail.stream}</span>}
          {detail.specialization && <span className="text-xs font-medium bg-accent/10 text-accent px-2.5 py-1 rounded-md">{detail.specialization}</span>}
        </div>
        <h1 className="font-heading text-2xl sm:text-3xl font-bold tracking-tight">{detail.full_title || detail.name}</h1>
        {detail.quick_summary && <p className="text-muted-foreground mt-2 text-sm sm:text-base max-w-2xl">{detail.quick_summary}</p>}
      </div>

      {/* Key info grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { icon: Clock, label: "Duration", value: detail.duration },
          { icon: DollarSign, label: "Salary (Entry)", value: detail.salary_entry },
          { icon: TrendingUp, label: "Growth", value: detail.growth_potential },
          { icon: Zap, label: "AI Impact", value: detail.ai_impact },
        ].filter(i => i.value).map((item, i) => (
          <div key={i} className="bg-card border border-border rounded-xl p-4">
            <item.icon className="h-4 w-4 text-primary" />
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mt-2">{item.label}</p>
            <p className="font-heading font-bold mt-0.5">{item.value}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Overview */}
          {detail.overview && (
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="font-heading font-bold flex items-center gap-2"><BookOpen className="h-4 w-4 text-primary" /> Overview</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{detail.overview}</p>
            </div>
          )}

          {/* Day in the life */}
          {detail.day_in_the_life && (
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="font-heading font-bold flex items-center gap-2"><Users className="h-4 w-4 text-primary" /> A Day in the Life</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{detail.day_in_the_life}</p>
            </div>
          )}

          {/* What you'll learn */}
          <TagSection title="What You'll Learn" items={detail.what_you_will_learn} color="bg-primary/10 text-primary" />

          {/* Career options */}
          <TagSection title="Career Options" items={detail.career_options} color="bg-accent/10 text-accent" />

          {/* Salary breakdown */}
          <div className="bg-card border border-border rounded-xl p-5 space-y-3">
            <h3 className="font-heading font-bold flex items-center gap-2"><DollarSign className="h-4 w-4 text-primary" /> Salary Guide</h3>
            <InfoRow icon={DollarSign} label="India" value={detail.salary_india} />
            <InfoRow icon={Globe} label="Global" value={detail.salary_global} />
            <InfoRow icon={Briefcase} label="Entry Level" value={detail.salary_entry} />
            <InfoRow icon={TrendingUp} label="Mid Level" value={detail.salary_mid} />
            <InfoRow icon={Star} label="Senior Level" value={detail.salary_senior} />
          </div>

          {/* AI Impact detail */}
          {detail.ai_impact_detail && (
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="font-heading font-bold flex items-center gap-2"><Zap className="h-4 w-4 text-primary" /> AI Impact Analysis</h3>
              <p className="text-sm text-muted-foreground mt-2">{detail.ai_impact_detail}</p>
            </div>
          )}

          {/* Pros & Cons */}
          <div className="grid sm:grid-cols-2 gap-4">
            {detail.pros && detail.pros.length > 0 && (
              <div className="bg-card border border-border rounded-xl p-5">
                <h3 className="font-heading font-bold text-green-600 text-sm mb-2">✅ Pros</h3>
                <ul className="space-y-1.5">
                  {detail.pros.map((p, i) => <li key={i} className="text-sm text-muted-foreground flex items-start gap-2"><span className="text-green-500 mt-1">•</span>{p}</li>)}
                </ul>
              </div>
            )}
            {detail.cons && detail.cons.length > 0 && (
              <div className="bg-card border border-border rounded-xl p-5">
                <h3 className="font-heading font-bold text-red-500 text-sm mb-2">⚠️ Cons</h3>
                <ul className="space-y-1.5">
                  {detail.cons.map((c, i) => <li key={i} className="text-sm text-muted-foreground flex items-start gap-2"><span className="text-red-400 mt-1">•</span>{c}</li>)}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          <div className="bg-card border border-border rounded-xl p-5 space-y-4">
            <InfoRow icon={Users} label="Personality Fit" value={detail.personality_fit} />
            <InfoRow icon={Brain} label="Stress Level" value={detail.stress_level} />
            <InfoRow icon={Clock} label="Work-Life Balance" value={detail.work_life_balance} />
            <InfoRow icon={Briefcase} label="Internships" value={detail.internship_opportunities} />
          </div>

          <TagSection title="Required Subjects" items={detail.required_subjects} />
          <TagSection title="Entrance Exams" items={detail.entrance_exams} color="bg-destructive/10 text-destructive" />
          <TagSection title="Skills Needed" items={detail.skills_needed} color="bg-primary/10 text-primary" />
          <TagSection title="Future-Proof Skills" items={detail.future_proof_skills} color="bg-accent/10 text-accent" />
          <TagSection title="Emerging Specializations" items={detail.emerging_specializations} />
          <TagSection title="Related Certifications" items={detail.related_certifications} />
          <TagSection title="Popular Locations" items={detail.popular_locations} />

          {detail.top_universities_india && detail.top_universities_india.length > 0 && (
            <div className="bg-card border border-border rounded-xl p-5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Top Universities (India)</p>
              <ul className="space-y-1">
                {detail.top_universities_india.map((u, i) => (
                  <li key={i} className="text-sm flex items-center gap-2"><GraduationCap className="h-3 w-3 text-primary shrink-0" />{u}</li>
                ))}
              </ul>
            </div>
          )}

          {detail.top_universities_global && detail.top_universities_global.length > 0 && (
            <div className="bg-card border border-border rounded-xl p-5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Top Universities (Global)</p>
              <ul className="space-y-1">
                {detail.top_universities_global.map((u, i) => (
                  <li key={i} className="text-sm flex items-center gap-2"><Globe className="h-3 w-3 text-accent shrink-0" />{u}</li>
                ))}
              </ul>
            </div>
          )}

          {detail.online_resources && detail.online_resources.length > 0 && (
            <div className="bg-card border border-border rounded-xl p-5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Online Resources</p>
              <ul className="space-y-1">
                {detail.online_resources.map((r, i) => (
                  <li key={i} className="text-sm text-muted-foreground">• {r}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}