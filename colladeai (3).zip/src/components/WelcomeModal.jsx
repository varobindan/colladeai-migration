import { Sparkles, Zap } from "lucide-react";
import { useCredits } from "@/hooks/useCredits";
import { useState } from "react";
import UpgradeModal from "./UpgradeModal";

export default function WelcomeModal() {
  const { markWelcomeShown, welcome_shown, _loaded } = useCredits();
  const [showUpgrade, setShowUpgrade] = useState(false);

  if (!_loaded || welcome_shown) return null;

  if (showUpgrade) {
    return <UpgradeModal canClose={false} onClose={async () => { await markWelcomeShown(); }} />;
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-card rounded-2xl border border-border shadow-2xl w-full max-w-sm text-center p-7">
        <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mx-auto mb-4">
          <Sparkles className="h-8 w-8 text-white" />
        </div>
        <h2 className="font-heading font-bold text-xl mb-1">Welcome to Collade AI!</h2>
        <p className="text-sm text-muted-foreground mb-6">
          Your AI-powered career guide. Start exploring for free or unlock the full experience.
        </p>
        <div className="space-y-3">
          <button
            onClick={markWelcomeShown}
            className="w-full flex items-center justify-center gap-2 bg-secondary border border-border rounded-xl py-3 text-sm font-semibold hover:bg-muted transition-colors"
          >
            <Zap className="h-4 w-4 text-primary" /> Continue for Free (5 Credits)
          </button>
          <button
            onClick={() => setShowUpgrade(true)}
            className="w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-xl py-3 text-sm font-semibold hover:opacity-90 transition-opacity shadow-lg shadow-primary/20"
          >
            <Sparkles className="h-4 w-4" /> Upgrade Now
          </button>
        </div>
        <p className="text-[10px] text-muted-foreground mt-4">Every AI action uses 1 credit</p>
      </div>
    </div>
  );
}