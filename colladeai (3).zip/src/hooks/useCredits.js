import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";

// Single shared promise so multiple components don't fire duplicate fetches
let sharedFetchPromise = null;
let cachedCredits = null;
const listeners = new Set();

function broadcast(state) {
  cachedCredits = state;
  listeners.forEach(fn => fn({ ...state }));
}

async function fetchCredits() {
  const me = await base44.auth.me();
  if (!me?.email) return null;

  const records = await base44.entities.UserCredit.filter({ created_by: me.email }, "-created_date", 1);

  if (records && records.length > 0) {
    const r = records[0];
    let plan = r.plan ?? "free";
    let credits = typeof r.credits_remaining === "number" ? r.credits_remaining : 0;
    if (credits < 0) credits = 0;

    // Check premium expiry
    if (plan === "premium" && r.subscription_expiry) {
      if (new Date(r.subscription_expiry) < new Date()) {
        plan = "free";
        credits = 0;
        // Update DB to reflect expiry
        await base44.entities.UserCredit.update(r.id, { plan: "free", credits_remaining: 0 });
      }
    }
    if (plan === "premium") credits = 9999;

    return {
      credits_remaining: credits,
      plan,
      access_locked: plan !== "premium" && credits <= 0,
      welcome_shown: r.welcome_shown ?? false,
      subscription_start: r.subscription_start ?? null,
      subscription_expiry: r.subscription_expiry ?? null,
      _id: r.id,
      _loaded: true,
    };
  } else {
    // New user — give 5 free credits
    const r = await base44.entities.UserCredit.create({
      credits_remaining: 5,
      plan: "free",
      access_locked: false,
      welcome_shown: false,
    });
    return {
      credits_remaining: 5,
      plan: "free",
      access_locked: false,
      welcome_shown: false,
      _id: r.id,
      _loaded: true,
    };
  }
}

function loadOnce() {
  if (sharedFetchPromise) return sharedFetchPromise;
  sharedFetchPromise = fetchCredits().then(state => {
    if (state) broadcast(state);
    return state;
  }).catch(err => {
    console.error("useCredits: failed to load credits", err);
    sharedFetchPromise = null; // allow retry
  });
  return sharedFetchPromise;
}

const DEFAULT_STATE = {
  credits_remaining: 0,
  plan: "free",
  access_locked: false,
  welcome_shown: false,
  subscription_start: null,
  subscription_expiry: null,
  _id: null,
  _loaded: false,
};

export function useCredits() {
  const [state, setState] = useState(() => cachedCredits || DEFAULT_STATE);

  useEffect(() => {
    listeners.add(setState);
    // If already cached, sync immediately
    if (cachedCredits) setState({ ...cachedCredits });
    // Always trigger load (it dedupes via sharedFetchPromise)
    loadOnce();
    return () => {
      listeners.delete(setState);
    };
  }, []);

  const deductCredit = useCallback(async () => {
    // Wait up to 5s for credits to load
    let waited = 0;
    while (!cachedCredits?._id && waited < 5000) {
      await new Promise(r => setTimeout(r, 100));
      waited += 100;
    }

    const current = cachedCredits;
    if (!current?._id) return false;

    // Premium users: never deduct, never touch DB
    if (current.plan === "premium") return true;

    if (current.credits_remaining <= 0) return false;

    const newCount = current.credits_remaining - 1;
    // Optimistic UI update
    broadcast({ ...current, credits_remaining: newCount, access_locked: newCount <= 0 });
    // Persist to DB — only for non-premium users
    try {
      await base44.entities.UserCredit.update(current._id, {
        credits_remaining: newCount,
        access_locked: newCount <= 0,
      });
    } catch (err) {
      console.warn("Credit update failed:", err?.message);
      // Don't block the user — optimistic update already applied
    }
    return true;
  }, []);

  const addCredits = useCallback(async (amount, plan, paymentId) => {
    const current = cachedCredits;
    if (!current?._id || !paymentId) return;
    const EXACT = { basic: 50, pro: 500, premium: 9999 };
    const newCount = EXACT[plan] ?? amount ?? 5;
    const startDate = new Date().toISOString();
    const expiryDate = plan === "premium"
      ? new Date(Date.now() + 6 * 30 * 24 * 60 * 60 * 1000).toISOString()
      : null;
    broadcast({ ...current, credits_remaining: newCount, plan, access_locked: false, subscription_start: startDate, subscription_expiry: expiryDate });
    try {
      await base44.entities.UserCredit.update(current._id, {
        credits_remaining: newCount, plan, access_locked: false,
        razorpay_payment_id: paymentId,
        subscription_start: startDate,
        subscription_expiry: expiryDate,
      });
    } catch (err) {
      console.warn("addCredits update failed:", err?.message);
    }
  }, []);

  const markWelcomeShown = useCallback(async () => {
    const current = cachedCredits;
    if (!current?._id) return;
    broadcast({ ...current, welcome_shown: true });
    try {
      await base44.entities.UserCredit.update(current._id, { welcome_shown: true });
    } catch (err) {
      console.warn("markWelcomeShown update failed:", err?.message);
    }
  }, []);

  const refetch = useCallback(async () => {
    sharedFetchPromise = null; // force re-fetch
    await loadOnce();
  }, []);

  return { ...state, deductCredit, addCredits, markWelcomeShown, refetch };
}